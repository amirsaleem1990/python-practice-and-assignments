#filename=('\\users\\hp\\Dropbox\\name.txt')
filename= ('\\bin\\name.txt')
"""Wordcount exercise
Python class
The main() below is already defined and complete. It calls print_words()
and print_top() functions which you write.
1. For the --count flag, implement a print_words(filename) function that counts
how often each word appears in the text and prints:
word1 count1
word2 count2
...
Print the above list in order sorted by word (python will sort punctuation to
come before letters -- that"s fine). Store all the words as lowercase,
so "The" and "the" count as the same word.
2. For the --topcount flag, implement a print_top(filename) which is similar
to print_words() but which prints just the top 20 most common words sorted
so the most common word is first, then the next most common, and so on.
Use str.split() (no arguments) to split on all whitespace.
Workflow: don"t build the whole program at once. Get it to an intermediate
milestone and print your data structure and sys.exit(0).
When that"s working, try for the next milestone.
Optional: define a helper function to avoid code duplication inside
print_words() and print_top().
"""

import sys

def lst_of_str(filename):
    file = open(filename, 'r')
    list_of_words = [i.lower() for i in file.read().split()]
    list_of_words.sort()
    return list_of_words

def nested_sorted_list_of_words(filename):
    zmz = lst_of_str(filename)
    b = []
    c = []
    for i in zmz:
        if i not in b:      
            z = zmz.count(i)
            b.append(i)
            c.append(i)
            c.append(z)
    # ab hamary pas aik list(c) h jis k andar file ka har word (bager repeat k) h, or us ki counting h k ye
    # word file me total kitni dafa repeat hwa tha.
    m = []
    for i in range(0, len(c), 2):
        m.append([c[i], c[i+1]])
    # ham ny 1 list ko nested list bana dya.. har list me file ka aik word or wo word kitni dafa file me
    # repeat hwa h ye dono chezen hen.
    return m
def choose_first_20(filename):
    zmz = lst_of_str(filename)
    b = []
    c = []
    for i in zmz:
        if i not in b:
            z = zmz.count(i)
            b.append(i)
            c.append(z)
            c.append(i)
        m = []
    for i in range(0, len(c), 2):
        m.append([c[i], c[i+1]])
    m.sort(reverse=True)
    return m

            
def print_words(filename):
    q = nested_sorted_list_of_words(filename)
    b = []
    r = []
    for i in range(len(q)):
        r.append([q[i][1] , q[i][0]])
        b = b + r
    return r

def print_top(filename):
    cmc = choose_first_20(filename)
    only20 = cmc[:21]
    for i in only20:
        i.reverse()
    only20.sort()
    return only20



  
# +++your code here+++
# Define print_words(filename) and print_top(filename) functions.
# You could write a helper utility function that reads a file
# and builds and returns a word/count dict for it.
# Then print_words() and print_top() can just call the utility function.

# This basic command line argument parsing code is provided and
# calls the print_words() and print_top() functions which you must define.

def main():
  if len(sys.argv) != 3:
    print("usage: ./wordcount.py {--count | --topcount} file")
    sys.exit(1)

  option = sys.argv[1]
  filename = sys.argv[2]
  if option == "--count":
    print_words(filename)
  elif option == "--topcount":
    print_top(filename)
  else:
    print("unknown option: " + str(option))
    sys.exit(1)

if __name__ == "__main__":
    print_top('\\bin\\name.txt')
